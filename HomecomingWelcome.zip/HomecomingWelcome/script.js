// DOM Content Loaded Event
document.addEventListener("DOMContentLoaded", function () {
    // Initialize all functions
    initializePage();
    displayCurrentDate();
    addScrollEffects();
    addInteractiveElements();
    startAnimations();
    trackVisitor();
    loadDuasFromDatabase();
});

// Initialize page with smooth loading
function initializePage() {
    // Add loading class to body
    document.body.classList.add("loading");

    // Remove loading class after short delay
    setTimeout(() => {
        document.body.classList.remove("loading");
    }, 500);

    // Add welcome message to console
    console.log("🕌 Selamat Pulang Ke Pondok Pesantren! 🕌");
    console.log("Barakallahu fiikum - Semoga Allah memberkahi kalian");
}

// Display current date in Islamic and Gregorian format
function displayCurrentDate() {
    const dateElement = document.getElementById("currentDate");
    // Set specific date: Saturday, July 19, 2025
    const specificDate = new Date(2025, 6, 19); // Month is 0-indexed, so 6 = July

    // Format Gregorian date
    const options = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
    };
    const gregorianDate = specificDate.toLocaleDateString("id-ID", options);

    // Get Islamic date (simplified calculation)
    const islamicDate = getIslamicDate(specificDate);

    // Display both dates
    dateElement.innerHTML = `
        <div class="date-gregorian">${gregorianDate}</div>
        <div class="date-islamic">${islamicDate}</div>
    `;

    // Animate date display
    animateElement(dateElement, "fadeIn", 1000);
}

// Simple Islamic date calculation (approximate)
function getIslamicDate(gregorianDate) {
    // This is a simplified calculation
    // In a real application, you would use a proper Islamic calendar library
    const islamicMonths = [
        "Muharram",
        "Safar",
        "Rabi' al-Awwal",
        "Rabi' al-Thani",
        "Jumada al-Awwal",
        "Jumada al-Thani",
        "Rajab",
        "Sha'ban",
        "Ramadan",
        "Shawwal",
        "Dhu al-Qi'dah",
        "Dhu al-Hijjah",
    ];

    // Approximate Islamic year calculation
    const islamicYear =
        Math.floor(((gregorianDate.getFullYear() - 622) * 365.25) / 354.367) +
        1;
    const islamicMonth = islamicMonths[gregorianDate.getMonth() % 12];
    const islamicDay = gregorianDate.getDate();

    return `${islamicDay} ${islamicMonth} ${islamicYear} H`;
}

// Add scroll effects and animations
function addScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px",
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("visible");

                // Add special effects for specific elements
                if (entry.target.classList.contains("welcome-text")) {
                    addWelcomeTextEffect(entry.target);
                }

                if (entry.target.classList.contains("arabic-text")) {
                    addArabicTextEffect(entry.target);
                }
            }
        });
    }, observerOptions);

    // Observe all animated elements
    const animatedElements = document.querySelectorAll(
        ".welcome-section, .dua-section, .achievement-section, .closing-section",
    );
    animatedElements.forEach((el) => observer.observe(el));
}

// Add special effect to welcome text
function addWelcomeTextEffect(element) {
    const text = element.textContent;
    element.innerHTML = "";

    // Split text into spans for individual letter animation
    text.split("").forEach((char, index) => {
        const span = document.createElement("span");
        span.textContent = char === " " ? "\u00A0" : char;
        span.style.animationDelay = `${index * 0.1}s`;
        span.classList.add("letter-animate");
        element.appendChild(span);
    });
}

// Add special effect to Arabic text
function addArabicTextEffect(element) {
    element.style.transform = "translateY(0)";
    element.style.opacity = "1";

    // Add pulsing effect
    setInterval(() => {
        element.style.transform = "scale(1.02)";
        setTimeout(() => {
            element.style.transform = "scale(1)";
        }, 200);
    }, 3000);
}

// Add interactive elements
function addInteractiveElements() {
    // Add hover effects to cards
    const cards = document.querySelectorAll(".card");
    cards.forEach((card) => {
        card.addEventListener("mouseenter", () => {
            card.style.transform = "translateY(-15px) scale(1.02)";
            card.style.boxShadow = "0 25px 60px rgba(0, 0, 0, 0.25)";
        });

        card.addEventListener("mouseleave", () => {
            card.style.transform = "translateY(0) scale(1)";
            card.style.boxShadow = "0 10px 30px rgba(0, 0, 0, 0.1)";
        });
    });

    // Add click effects to message cards
    const messageCards = document.querySelectorAll(
        ".message-card, .dua-container, .closing-message",
    );
    messageCards.forEach((card) => {
        card.addEventListener("click", () => {
            card.style.transform = "scale(0.98)";
            setTimeout(() => {
                card.style.transform = "scale(1)";
            }, 150);
        });
    });

    // Add Islamic greeting on page interaction
    let greetingShown = false;
    document.addEventListener("click", () => {
        if (!greetingShown) {
            showIslamicGreeting();
            greetingShown = true;
        }
    });
}

// Show Islamic greeting notification
function showIslamicGreeting() {
    const greeting = document.createElement("div");
    greeting.className = "islamic-greeting-popup";
    greeting.innerHTML = `
        <div class="greeting-content">
            <i class="fas fa-star-and-crescent"></i>
            <p>Assalamu'alaikum Warahmatullahi Wabarakatuh</p>
            <small>Selamat pulang ke pondok pesantren sayanggggg<3</small>
        </div>
    `;

    document.body.appendChild(greeting);

    // Animate greeting
    setTimeout(() => {
        greeting.classList.add("show");
    }, 100);

    // Remove greeting after delay
    setTimeout(() => {
        greeting.classList.remove("show");
        setTimeout(() => {
            document.body.removeChild(greeting);
        }, 500);
    }, 3000);
}

// Start continuous animations
function startAnimations() {
    // Animate Islamic symbols
    const islamicSymbols = document.querySelectorAll(
        ".islamic-symbol i, .dua-header i",
    );
    islamicSymbols.forEach((symbol) => {
        setInterval(() => {
            symbol.style.transform = "rotate(5deg) scale(1.1)";
            setTimeout(() => {
                symbol.style.transform = "rotate(0deg) scale(1)";
            }, 300);
        }, 4000);
    });

    // Animate decoration lines
    const decorationLines = document.querySelectorAll(".decoration-line");
    decorationLines.forEach((line) => {
        setInterval(() => {
            line.style.background = "linear-gradient(90deg, #f39c12, #27ae60)";
            setTimeout(() => {
                line.style.background =
                    "linear-gradient(90deg, #27ae60, #f39c12)";
            }, 1000);
        }, 2000);
    });

    // Create floating elements periodically
    setInterval(() => {
        createFloatingElement();
    }, 3000);
}

// Create floating Islamic elements
function createFloatingElement() {
    const elements = ["🕌", "⭐", "🌙", "✨"];
    const element = document.createElement("div");
    element.className = "floating-element";
    element.textContent = elements[Math.floor(Math.random() * elements.length)];
    element.style.cssText = `
        position: fixed;
        left: ${Math.random() * 100}vw;
        top: 100vh;
        font-size: 1.5rem;
        pointer-events: none;
        z-index: 10;
        animation: floatUp 4s ease-out forwards;
    `;

    document.body.appendChild(element);

    // Remove element after animation
    setTimeout(() => {
        if (element.parentNode) {
            element.parentNode.removeChild(element);
        }
    }, 4000);
}

// Utility function to animate elements
function animateElement(element, animationClass, duration = 1000) {
    element.classList.add(animationClass);

    setTimeout(() => {
        element.classList.remove(animationClass);
    }, duration);
}

// Add keyboard shortcuts for accessibility
document.addEventListener("keydown", (e) => {
    // Press 'D' for dua
    if (e.key.toLowerCase() === "d") {
        document.querySelector(".dua-section").scrollIntoView({
            behavior: "smooth",
        });
    }

    // Press 'W' for welcome
    if (e.key.toLowerCase() === "w") {
        document.querySelector(".welcome-section").scrollIntoView({
            behavior: "smooth",
        });
    }

    // Press 'A' for achievements
    if (e.key.toLowerCase() === "a") {
        document.querySelector(".achievement-section").scrollIntoView({
            behavior: "smooth",
        });
    }
});

// Add additional CSS for dynamic elements
const additionalCSS = `
    .letter-animate {
        display: inline-block;
        opacity: 0;
        animation: letterFadeIn 0.8s ease-out forwards;
    }
    
    @keyframes letterFadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .islamic-greeting-popup {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.8);
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(15px);
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        z-index: 1000;
        opacity: 0;
        transition: all 0.5s ease;
        border: 2px solid rgba(39, 174, 96, 0.3);
    }
    
    .islamic-greeting-popup.show {
        opacity: 1;
        transform: translate(-50%, -50%) scale(1);
    }
    
    .greeting-content {
        text-align: center;
        color: #2c3e50;
    }
    
    .greeting-content i {
        font-size: 2rem;
        color: #27ae60;
        margin-bottom: 10px;
    }
    
    .greeting-content p {
        font-size: 1.1rem;
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .greeting-content small {
        color: #7f8c8d;
        font-style: italic;
    }
    
    .floating-element {
        animation: floatUp 4s ease-out forwards;
    }
    
    @keyframes floatUp {
        0% {
            transform: translateY(0) rotate(0deg);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        100% {
            transform: translateY(-100vh) rotate(360deg);
            opacity: 0;
        }
    }
    
    .date-gregorian {
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .date-islamic {
        font-size: 0.9rem;
        color: #7f8c8d;
        font-style: italic;
    }
`;

// Inject additional CSS
const styleSheet = document.createElement("style");
styleSheet.textContent = additionalCSS;
document.head.appendChild(styleSheet);

// Track visitor function
async function trackVisitor() {
    try {
        const response = await fetch("/api/visitors", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                ipAddress: "visitor",
                userAgent: navigator.userAgent,
            }),
        });

        if (response.ok) {
            console.log("Visitor tracked successfully");
        }
    } catch (error) {
        console.log("Could not track visitor:", error);
    }
}

// Load duas from database
async function loadDuasFromDatabase() {
    try {
        const response = await fetch("/api/duas");
        if (response.ok) {
            const duas = await response.json();
            console.log("Loaded", duas.length, "duas from database");
            // You can use the duas to enhance the page content
        }
    } catch (error) {
        console.log("Could not load duas from database:", error);
    }
}

// Console welcome message with Islamic styling
console.log(`
🕌 ═══════════════════════════════════════════════════════════ 🕌
   بِسْمِ اللّهِ الرَّحْمَنِ الرَّحِيْمِ
   Selamat Pulang dari Pondok Pesantren!
   Barakallahu fiikum - Semoga Allah memberkahi kalian
🕌 ═══════════════════════════════════════════════════════════ 🕌
`);
