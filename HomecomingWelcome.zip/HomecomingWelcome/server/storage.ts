import { users, welcomeMessages, duas, visitors, type User, type InsertUser, type WelcomeMessage, type InsertWelcomeMessage, type Dua, type InsertDua, type Visitor, type InsertVisitor } from "../shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  
  // Welcome message operations
  getWelcomeMessages(): Promise<WelcomeMessage[]>;
  createWelcomeMessage(insertMessage: InsertWelcomeMessage): Promise<WelcomeMessage>;
  
  // Dua operations
  getDuas(): Promise<Dua[]>;
  createDua(insertDua: InsertDua): Promise<Dua>;
  
  // Visitor operations
  trackVisitor(insertVisitor: InsertVisitor): Promise<Visitor>;
  getVisitorStats(): Promise<{ totalVisitors: number; todayVisitors: number }>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getWelcomeMessages(): Promise<WelcomeMessage[]> {
    return await db.select().from(welcomeMessages).orderBy(desc(welcomeMessages.createdAt));
  }

  async createWelcomeMessage(insertMessage: InsertWelcomeMessage): Promise<WelcomeMessage> {
    const [message] = await db
      .insert(welcomeMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getDuas(): Promise<Dua[]> {
    return await db.select().from(duas).where(eq(duas.isActive, true));
  }

  async createDua(insertDua: InsertDua): Promise<Dua> {
    const [dua] = await db
      .insert(duas)
      .values(insertDua)
      .returning();
    return dua;
  }

  async trackVisitor(insertVisitor: InsertVisitor): Promise<Visitor> {
    const [visitor] = await db
      .insert(visitors)
      .values(insertVisitor)
      .returning();
    return visitor;
  }

  async getVisitorStats(): Promise<{ totalVisitors: number; todayVisitors: number }> {
    const totalVisitors = await db.select().from(visitors);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayVisitors = await db.select().from(visitors).where(eq(visitors.visitedAt, today));
    
    return {
      totalVisitors: totalVisitors.length,
      todayVisitors: todayVisitors.length
    };
  }
}

export const storage = new DatabaseStorage();