import { pgTable, serial, text, timestamp, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Users table for storing visitor information
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique().notNull(),
  email: text("email").unique(),
  fullName: text("full_name"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

// Welcome messages table for storing personalized welcome messages
export const welcomeMessages = pgTable("welcome_messages", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  message: text("message").notNull(),
  arabicMessage: text("arabic_message"),
  isPublic: boolean("is_public").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

// Dua/prayers table for storing Islamic prayers
export const duas = pgTable("duas", {
  id: serial("id").primaryKey(),
  arabicText: text("arabic_text").notNull(),
  transliteration: text("transliteration"),
  translation: text("translation").notNull(),
  category: text("category").default("general"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

// Visitor tracking table
export const visitors = pgTable("visitors", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  visitedAt: timestamp("visited_at").defaultNow(),
  pageViews: serial("page_views")
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  welcomeMessages: many(welcomeMessages)
}));

export const welcomeMessagesRelations = relations(welcomeMessages, ({ one }) => ({
  user: one(users, {
    fields: [welcomeMessages.userId],
    references: [users.id]
  })
}));

// Types for TypeScript
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type WelcomeMessage = typeof welcomeMessages.$inferSelect;
export type InsertWelcomeMessage = typeof welcomeMessages.$inferInsert;
export type Dua = typeof duas.$inferSelect;
export type InsertDua = typeof duas.$inferInsert;
export type Visitor = typeof visitors.$inferSelect;
export type InsertVisitor = typeof visitors.$inferInsert;