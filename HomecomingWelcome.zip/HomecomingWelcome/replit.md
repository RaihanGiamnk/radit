# Replit.md

## Overview

This is a static web application that creates a welcoming page for students returning from "Pondok Pesantren" (Islamic boarding school). The application features a beautiful Islamic-themed design with Arabic greetings, animated particles, and both Gregorian and Islamic date displays. It's built using vanilla HTML, CSS, and JavaScript with a focus on visual aesthetics and smooth animations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

**Full-Stack Architecture**: Frontend with Node.js/Express backend and PostgreSQL database
- **Frontend**: Single-page application with HTML/CSS/JS
- **Backend**: Node.js Express API server with TypeScript support
- **Database**: PostgreSQL with Drizzle ORM for data management
- **Structure**: API endpoints for data operations, static file serving
- **Rendering**: Client-side DOM manipulation with database integration

**Backend Components**:
- Express.js API server on port 5000
- PostgreSQL database with Drizzle ORM
- RESTful API endpoints for duas, messages, and visitor tracking
- TypeScript for type safety

## Key Components

### 1. HTML Structure (index.html)
- Semantic HTML5 structure
- Islamic-themed content with Arabic text
- Font integration (Google Fonts: Amiri for Arabic, Poppins for Latin)
- FontAwesome icons for Islamic symbols
- Responsive viewport configuration

### 2. Styling System (style.css)
- **Reset**: Universal box-sizing and margin/padding reset
- **Design System**: Islamic-inspired color palette with gradients
- **Animations**: CSS keyframe animations for floating particles
- **Typography**: Multi-font system supporting Arabic and Latin scripts
- **Background Effects**: Layered background with patterns and gradients
- **Responsive Design**: Mobile-first approach with flexible layouts

### 3. JavaScript Functionality (script.js)
- **Page Initialization**: Smooth loading transitions
- **Date Display**: Dual calendar system (Gregorian and Islamic)
- **Animations**: Particle effects and scroll-based animations
- **Interactive Elements**: Dynamic DOM manipulation
- **Console Logging**: Development-friendly debugging messages

## Data Flow

1. **Page Load**: 
   - DOM content loaded event triggers initialization
   - Loading state management
   - Date calculation and display

2. **User Interaction**:
   - Scroll effects activation
   - Interactive element responses
   - Animation triggers

3. **Visual Effects**:
   - Continuous particle animations
   - Smooth transitions between states
   - Responsive design adjustments

## External Dependencies

### CDN Resources
- **Google Fonts**: Amiri (Arabic) and Poppins (Latin) font families
- **FontAwesome**: Version 6.4.0 for Islamic iconography
- **No JavaScript Libraries**: Pure vanilla JavaScript implementation

### Asset References
- **Background Pattern**: References `assets/pattern.svg` (not included in current files)
- **Fonts**: External Google Fonts API

## Deployment Strategy

**Static Hosting Compatible**: This application can be deployed on any static hosting platform including:
- GitHub Pages
- Netlify
- Vercel
- Traditional web servers
- CDN-based hosting

**Requirements**:
- No server-side processing needed
- No database requirements
- No build process required
- Direct file serving capability

**Performance Considerations**:
- Optimized for fast loading with minimal dependencies
- CSS and JavaScript are embedded/linked for quick rendering
- External resources are loaded from reliable CDNs
- Animations are CSS-based for smooth performance

**Browser Compatibility**:
- Modern browsers with ES6+ support
- CSS3 animation support required
- Responsive design for mobile and desktop

## Key Features

1. **Islamic Theme**: Culturally appropriate design with Arabic text and Islamic symbols
2. **Dual Calendar**: Both Gregorian and Islamic date display
3. **Smooth Animations**: Particle effects and transition animations
4. **Responsive Design**: Mobile-friendly layout
5. **Performance Optimized**: Lightweight with minimal dependencies
6. **Accessibility**: Semantic HTML structure with proper heading hierarchy

## Development Notes

- The application uses Indonesian language for the main content
- Islamic calendar calculation is simplified and may need enhancement for accuracy
- Background pattern SVG file is referenced but not included in the current repository
- Code is well-structured with clear separation of concerns
- Console logging provides developer feedback during initialization